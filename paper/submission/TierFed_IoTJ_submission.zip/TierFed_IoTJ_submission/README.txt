TierFed: Every Round Is a Release -- submission package
=======================================================

Manuscript (IEEEtran, journal mode)
  main.tex                         the article, one self-contained file
  main.bbl                         compiled bibliography (BibTeX not needed)
  TierFed_manuscript.pdf           the compiled article

Supplementary material
  supp.tex, supp.bbl               the supplement, one self-contained file
  TierFed_supplementary_material.pdf

Shared
  figures/                         every figure the two files include (PDF, fonts embedded)
  references.bib                   the bibliography database (for a fresh BibTeX run)
  cover_letter.md                  cover letter; confirm the two bracketed items before sending

Build (TeX Live or MiKTeX with the standard IEEEtran class):
  pdflatex main && pdflatex main          (main.bbl is included)
  or: pdflatex main && bibtex main && pdflatex main && pdflatex main
  and the same for supp.

Every number, table and figure was generated from the per-seed logs by the code at
https://github.com/Abraheem13/tierfed (one command: scripts/reproduce_v6) and is
written here as plain text, so the sources need no generated files.
